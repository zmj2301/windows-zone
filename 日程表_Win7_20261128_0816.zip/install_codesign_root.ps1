# Install the self-signed code-signing certificate for the current user.
#
# This makes Windows trust the ScheduleMate self-signed publisher on THIS
# Windows account. It does NOT make the certificate publicly trusted.
#
# Run:
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\install_codesign_root.ps1
#
# To uninstall later:
#   certutil -delstore -user Root 73D40425F54944CFDB487FD8EE2DCB0A96B6BF40
#   certutil -delstore -user TrustedPublisher 73D40425F54944CFDB487FD8EE2DCB0A96B6BF40

$ErrorActionPreference = 'Stop'

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Candidates = @(
    (Join-Path $Here 'codesign_selfsigned.cer'),
    (Join-Path $env:USERPROFILE '.schedule_signing\codesign_selfsigned.cer')
)
$Cer = $Candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Cer) { throw 'codesign_selfsigned.cer not found' }

Write-Host "Using certificate: $Cer"
certutil -addstore -user Root $Cer
if ($LASTEXITCODE -ne 0) { throw 'Failed to add certificate to CurrentUser Root' }

certutil -addstore -user TrustedPublisher $Cer
if ($LASTEXITCODE -ne 0) {
    # Root is enough for signtool /pa verification. TrustedPublisher can be
    # blocked by some security software; warn but do not fail the install.
    Write-Warning 'Could not add to CurrentUser TrustedPublisher; Root install is enough for signature verification.'
} else {
    Write-Host 'Added to CurrentUser TrustedPublisher.'
}

Write-Host ''
Write-Host 'Done. The self-signed publisher is trusted for the current Windows user.'
Write-Host 'Close and reopen the exe properties to see the signature.'
